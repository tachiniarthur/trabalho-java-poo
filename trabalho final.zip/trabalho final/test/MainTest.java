import org.junit.Assert;
import org.junit.Test;

public class MainTest {

    @Test
    public void testEscreverDadosAlunos() {
        Aluno aluno1 = new Aluno("Matheus", 5f, 2f, 1f);
        Aluno aluno2 = new Aluno("Arthur", 1f, 2f, 3f);
        Aluno aluno3 = new Aluno("Gabriel", 6f, 7f, 4f);

        Main.escreverDadosAlunos("dados_teste.txt", aluno1, aluno2, aluno3);

        // Verificar se o arquivo foi criado
        java.io.File arquivo = new java.io.File("dados_teste.txt");
        Assert.assertTrue(arquivo.exists());

        // Verificar se os dados foram escritos corretamente no arquivo
        String[] linhas = lerLinhasArquivo("dados_teste.txt");
        Assert.assertEquals("Nome=Matheus, Nota Prova 1=5.0, Nota Prova 2=2.0, Nota trabalho=1.0]", linhas[0]);
        Assert.assertEquals("Nome=Arthur, Nota Prova 1=1.0, Nota Prova 2=2.0, Nota trabalho=3.0]", linhas[1]);
        Assert.assertEquals("Nome=Gabriel, Nota Prova 1=6.0, Nota Prova 2=7.0, Nota trabalho=4.0]", linhas[2]);

        // Remover o arquivo de teste
        arquivo.delete();
    }

    @Test
    public void testLerDadosAlunos() {
        // Criar um arquivo de teste com dados
        String[] dados = {
                "Nome=Matheus, Nota Prova 1=5.0, Nota Prova 2=2.0, Nota trabalho=1.0]",
                "Nome=Arthur, Nota Prova 1=1.0, Nota Prova 2=2.0, Nota trabalho=3.0]",
                "Nome=Gabriel, Nota Prova 1=6.0, Nota Prova 2=7.0, Nota trabalho=4.0]"
        };
        criarArquivoTeste("dados_teste.txt", dados);

        // Ler os dados do arquivo
        Main.lerDadosAlunos("dados_teste.txt");

        // Não há verificações específicas aqui, pois o método apenas imprime as linhas lidas no console
        // Certifique-se de verificar a saída no console para garantir que os dados tenham sido lidos corretamente

        // Remover o arquivo de teste
        java.io.File arquivo = new java.io.File("dados_teste.txt");
        arquivo.delete();
    }

    private String[] lerLinhasArquivo(String nomeArquivo) {
        try (java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.FileReader(nomeArquivo))) {
            java.util.List<String> linhas = new java.util.ArrayList<>();
            String linha;
            while ((linha = reader.readLine()) != null) {
                linhas.add(linha);
            }
            return linhas.toArray(new String[0]);
        } catch (java.io.IOException e) {
            e.printStackTrace();
        }
        return new String[0];
    }

    private void criarArquivoTeste(String nomeArquivo, String[] linhas) {
        try (java.io.BufferedWriter writer = new java.io.BufferedWriter(new java.io.FileWriter(nomeArquivo))) {
            for (String linha : linhas) {
                writer.write(linha);
                writer.newLine();
            }
        } catch (java.io.IOException e) {
            e.printStackTrace();
        }
    }
}
