package junit.tests.framework;

/**
 * Test class used in SuiteTest
 */
public class NoTestCaseClass extends Object {
    public void testSuccess() {
    }
}