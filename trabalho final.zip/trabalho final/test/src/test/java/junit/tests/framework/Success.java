package junit.tests.framework;

import junit.framework.TestCase;

/**
 * A test case testing the testing framework.
 */
public class Success extends TestCase {

    @Override
    public void runTest() {
    }

    public void testSuccess() {
    }
}