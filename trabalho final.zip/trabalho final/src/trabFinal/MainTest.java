package trabFinal;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MainTest {

    @Test
    void main() {
    }

    @Test
    void escreverDadosAlunos() {
    }

    @Test
    void lerDadosAlunos() {
    }
}